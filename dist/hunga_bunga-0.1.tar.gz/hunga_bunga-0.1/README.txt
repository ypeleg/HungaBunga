Lol, why do you read this?
